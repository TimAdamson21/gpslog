package com.example.gpslog;

public class Track {
	String time;
	double latitude;
	double longitude;
	double speed;
	String serial;
}
